// services/klingAI.js
// يتعامل مع Kling AI الرسمي (نص->فيديو، صورة->فيديو)
// المصادقة عبر JWT موقّع من Access Key + Secret Key (صالح لمدة 30 دقيقة)
// التوثيق: https://klingai.com (لوحة المطورين)

const jwt = require("jsonwebtoken");

const ACCESS_KEY = process.env.KLING_ACCESS_KEY;
const SECRET_KEY = process.env.KLING_SECRET_KEY;
const BASE_URL = process.env.KLING_BASE_URL || "https://api.klingai.com";

function assertConfigured() {
  if (!ACCESS_KEY || !SECRET_KEY) {
    throw new Error("KLING_ACCESS_KEY أو KLING_SECRET_KEY غير مضبوطين في .env");
  }
}

// توليد توكن JWT صالح لكل طلب (لا داعي لتخزينه، التوليد سريع جدًا)
function generateToken() {
  assertConfigured();
  const nowSec = Math.floor(Date.now() / 1000);
  const payload = {
    iss: ACCESS_KEY,
    exp: nowSec + 1800, // صلاحية 30 دقيقة
    nbf: nowSec - 5, // هامش لفروق الساعة
  };
  return jwt.sign(payload, SECRET_KEY, {
    algorithm: "HS256",
    header: { typ: "JWT" },
  });
}

async function klingRequest(path, method = "GET", body = null) {
  const token = generateToken();
  const res = await fetch(`${BASE_URL}${path}`, {
    method,
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    },
    body: body ? JSON.stringify(body) : undefined,
  });

  const json = await res.json();
  if (!res.ok) {
    throw new Error(
      `خطأ من Kling AI (${res.status}): ${json?.message || JSON.stringify(json)}`
    );
  }
  return json;
}

/**
 * إنشاء فيديو من نص
 * @param {object} params
 * @param {string} params.prompt
 * @param {number} [params.duration=5] - المدة بالثواني (5 أو 10 غالبًا)
 * @param {string} [params.aspectRatio="16:9"]
 * @param {string} [params.model="kling-v2.6-pro"]
 */
async function textToVideo({
  prompt,
  duration = 5,
  aspectRatio = "16:9",
  model = "kling-v2.6-pro",
}) {
  const json = await klingRequest("/v1/videos/text2video", "POST", {
    model,
    prompt,
    duration,
    aspect_ratio: aspectRatio,
  });
  return { taskId: json.task_id || json.data?.task_id, raw: json };
}

/**
 * إنشاء فيديو من صورة ثابتة (تحريك الصورة)
 * @param {object} params
 * @param {string} params.imageUrl - رابط عام للصورة (أو استخدم imageBase64)
 * @param {string} [params.imageBase64]
 * @param {string} [params.prompt] - وصف الحركة المطلوبة، مثال: "اجعل الشعر يتحرك مع الريح"
 * @param {number} [params.duration=5]
 * @param {string} [params.model="kling-v2.6-pro"]
 */
async function imageToVideo({
  imageUrl,
  imageBase64,
  prompt = "",
  duration = 5,
  model = "kling-v2.6-pro",
}) {
  const body = {
    model,
    prompt,
    duration,
    ...(imageUrl ? { image_url: imageUrl } : { image_base64: imageBase64 }),
  };
  const json = await klingRequest("/v1/videos/image2video", "POST", body);
  return { taskId: json.task_id || json.data?.task_id, raw: json };
}

/**
 * الاستعلام عن حالة مهمة فيديو (المعالجة تتم بشكل غير متزامن)
 * @param {string} taskId
 */
async function getTaskStatus(taskId) {
  const json = await klingRequest(`/v1/videos/${taskId}`, "GET");
  return json;
}

module.exports = { textToVideo, imageToVideo, getTaskStatus };
