// services/googleAI.js
// يتعامل مع Google AI Studio (Gemini 2.5 Flash Image / "Nano Banana")
// التوثيق: https://ai.google.dev/gemini-api/docs/image-generation

const GOOGLE_API_KEY = process.env.GOOGLE_AI_API_KEY;
const MODEL = process.env.GOOGLE_IMAGE_MODEL || "gemini-2.5-flash-image";
const BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models";

function assertConfigured() {
  if (!GOOGLE_API_KEY) {
    throw new Error("GOOGLE_AI_API_KEY غير مضبوط في ملف .env");
  }
}

// استخراج أول صورة (base64) من رد Gemini
function extractImageFromResponse(json) {
  const parts = json?.candidates?.[0]?.content?.parts || [];
  const imagePart = parts.find((p) => p.inlineData?.data);
  if (!imagePart) {
    const textPart = parts.find((p) => p.text);
    throw new Error(
      "لم يتم إرجاع صورة من النموذج. رد النموذج: " +
        (textPart?.text || JSON.stringify(json))
    );
  }
  return {
    base64: imagePart.inlineData.data,
    mimeType: imagePart.inlineData.mimeType || "image/png",
  };
}

/**
 * توليد صورة جديدة من نص فقط
 * @param {string} prompt - وصف الصورة المطلوبة
 */
async function generateImage(prompt) {
  assertConfigured();
  const url = `${BASE_URL}/${MODEL}:generateContent?key=${GOOGLE_API_KEY}`;

  const body = {
    contents: [
      {
        parts: [{ text: prompt }],
      },
    ],
  };

  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });

  const json = await res.json();
  if (!res.ok) {
    throw new Error(
      `خطأ من Google AI (${res.status}): ${json?.error?.message || "غير معروف"}`
    );
  }

  return extractImageFromResponse(json);
}

/**
 * تعديل صورة موجودة بناءً على وصف نصي (يحافظ على الهوية/التفاصيل الأساسية)
 * @param {string} imageBase64 - الصورة الأصلية بصيغة base64 (بدون بادئة data:)
 * @param {string} mimeType - مثل image/jpeg أو image/png
 * @param {string} prompt - وصف التعديل المطلوب، مثال: "غيّر خلفية الصورة إلى شاطئ عند الغروب"
 */
async function editImage(imageBase64, mimeType, prompt) {
  assertConfigured();
  const url = `${BASE_URL}/${MODEL}:generateContent?key=${GOOGLE_API_KEY}`;

  const body = {
    contents: [
      {
        parts: [
          { inlineData: { mimeType, data: imageBase64 } },
          { text: prompt },
        ],
      },
    ],
  };

  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });

  const json = await res.json();
  if (!res.ok) {
    throw new Error(
      `خطأ من Google AI (${res.status}): ${json?.error?.message || "غير معروف"}`
    );
  }

  return extractImageFromResponse(json);
}

module.exports = { generateImage, editImage };
