// server.js
require("dotenv").config();
const express = require("express");
const cors = require("cors");
const rateLimit = require("express-rate-limit");

const apiKeyAuth = require("./middleware/apiKeyAuth");
const imageRoutes = require("./routes/image");
const videoRoutes = require("./routes/video");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json({ limit: "15mb" }));

// حماية بسيطة من الإفراط في الطلبات (يحميك من فاتورة ضخمة مفاجئة)
const limiter = rateLimit({
  windowMs: 60 * 1000, // دقيقة واحدة
  max: 20, // 20 طلب كحد أقصى لكل IP في الدقيقة
  message: { error: "طلبات كثيرة جدًا، حاول لاحقًا" },
});
app.use("/api/", limiter);

// فحص صحة الخادم (لا يحتاج مفتاح)
app.get("/health", (req, res) => res.json({ status: "ok" }));

// كل مسارات /api تتطلب مفتاح التطبيق
app.use("/api", apiKeyAuth);
app.use("/api/image", imageRoutes);
app.use("/api/video", videoRoutes);

app.use((req, res) => res.status(404).json({ error: "المسار غير موجود" }));

app.listen(PORT, () => {
  console.log(`✅ الخادم يعمل على http://localhost:${PORT}`);
});
