// routes/video.js
const express = require("express");
const { textToVideo, imageToVideo, getTaskStatus } = require("../services/klingAI");

const router = express.Router();

// POST /api/video/text-to-video  { "prompt": "...", "duration": 5, "aspectRatio": "16:9" }
router.post("/text-to-video", async (req, res) => {
  try {
    const { prompt, duration, aspectRatio } = req.body;
    if (!prompt || !prompt.trim()) {
      return res.status(400).json({ error: "الحقل prompt مطلوب" });
    }
    const result = await textToVideo({ prompt, duration, aspectRatio });
    res.json({ success: true, taskId: result.taskId });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/video/image-to-video  { "imageUrl": "...", "prompt": "...", "duration": 5 }
// أو { "imageBase64": "...", "prompt": "..." }
router.post("/image-to-video", async (req, res) => {
  try {
    const { imageUrl, imageBase64, prompt, duration } = req.body;
    if (!imageUrl && !imageBase64) {
      return res.status(400).json({ error: "يجب توفير imageUrl أو imageBase64" });
    }
    const result = await imageToVideo({ imageUrl, imageBase64, prompt, duration });
    res.json({ success: true, taskId: result.taskId });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/video/status/:taskId
// التطبيق يستدعي هذا كل بضع ثوانٍ (polling) حتى تصبح الحالة "succeed"
router.get("/status/:taskId", async (req, res) => {
  try {
    const status = await getTaskStatus(req.params.taskId);
    res.json({ success: true, status });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
