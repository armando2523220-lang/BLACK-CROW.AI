// routes/image.js
const express = require("express");
const multer = require("multer");
const { generateImage, editImage } = require("../services/googleAI");

const router = express.Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } });

// POST /api/image/generate  { "prompt": "..." }
router.post("/generate", async (req, res) => {
  try {
    const { prompt } = req.body;
    if (!prompt || !prompt.trim()) {
      return res.status(400).json({ error: "الحقل prompt مطلوب" });
    }
    const result = await generateImage(prompt);
    res.json({
      success: true,
      mimeType: result.mimeType,
      imageBase64: result.base64, // التطبيق يحوّلها مباشرة إلى Bitmap
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/image/edit  (multipart/form-data)  حقول: image (ملف) + prompt (نص)
router.post("/edit", upload.single("image"), async (req, res) => {
  try {
    const { prompt } = req.body;
    if (!req.file) {
      return res.status(400).json({ error: "الملف image مطلوب" });
    }
    if (!prompt || !prompt.trim()) {
      return res.status(400).json({ error: "الحقل prompt مطلوب" });
    }

    const imageBase64 = req.file.buffer.toString("base64");
    const mimeType = req.file.mimetype;

    const result = await editImage(imageBase64, mimeType, prompt);
    res.json({
      success: true,
      mimeType: result.mimeType,
      imageBase64: result.base64,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
