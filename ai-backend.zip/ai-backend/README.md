# خادم AI Image/Video Backend

خادم وسيط بـ Node.js يربط تطبيق أندرويد بـ:
- **Google AI Studio (Gemini 2.5 Flash Image / Nano Banana)** → توليد صور من نص، وتعديل صور موجودة
- **Kling AI** → تحويل نص إلى فيديو، وتحويل صورة إلى فيديو

## 1. لماذا يوجد خادم وسيط أصلاً؟

لا تضع مفاتيح API داخل تطبيق الأندرويد مباشرة — يمكن استخراجها من ملف الـ APK بسهولة بواسطة أي شخص. الخادم الوسيط يخفي المفاتيح، ويتحكم بالحدود، ويمنع سوء الاستخدام عبر `x-app-key`.

## 2. التثبيت والتشغيل محليًا

```bash
cd ai-backend
npm install
cp .env.example .env
# افتح .env وضع مفاتيحك (راجع القسم 3)
npm start
```

الخادم يعمل افتراضيًا على `http://localhost:3000`.

## 3. الحصول على المفاتيح (مجانًا)

| الخدمة | الرابط | ماذا تحصل عليه |
|---|---|---|
| Google AI Studio | https://aistudio.google.com/app/apikey | مفتاح API واحد، مجاني حتى ~1000 صورة/يوم |
| Kling AI | https://klingai.com → لوحة المطورين | Access Key + Secret Key، رصيد مجاني يومي |

ضعها في ملف `.env`:
```
GOOGLE_AI_API_KEY=...
KLING_ACCESS_KEY=...
KLING_SECRET_KEY=...
APP_SECRET_KEY=اي-نص-عشوائي-طويل-تختاره-انت
```

## 4. نقاط النهاية (Endpoints)

كل الطلبات على `/api/*` تتطلب الهيدر:
```
x-app-key: نفس-قيمة-APP_SECRET_KEY
```

### توليد صورة من نص
```
POST /api/image/generate
Content-Type: application/json

{ "prompt": "قطة ترتدي نظارة شمسية، أسلوب كرتوني" }
```
الرد: `{ success, mimeType, imageBase64 }`

### تعديل صورة موجودة
```
POST /api/image/edit
Content-Type: multipart/form-data

image: <ملف الصورة>
prompt: "غيّر الخلفية إلى شاطئ عند الغروب"
```

### نص → فيديو
```
POST /api/video/text-to-video
{ "prompt": "قطة تعزف البيانو في نادي جاز", "duration": 5, "aspectRatio": "16:9" }
```
الرد: `{ success, taskId }`

### صورة → فيديو
```
POST /api/video/image-to-video
{ "imageUrl": "https://...jpg", "prompt": "اجعل الشعر يتحرك مع الريح", "duration": 5 }
```

### متابعة حالة الفيديو (Polling)
```
GET /api/video/status/:taskId
```
استدعِ هذا كل 3-5 ثوانٍ حتى تصبح الحالة "succeed" ثم يظهر رابط الفيديو داخل الرد.

## 5. الربط من تطبيق أندرويد (Kotlin + Retrofit)

```kotlin
interface AiApiService {
    @Headers("Content-Type: application/json")
    @POST("api/image/generate")
    suspend fun generateImage(
        @Header("x-app-key") appKey: String,
        @Body body: GenerateImageRequest
    ): GenerateImageResponse

    @Multipart
    @POST("api/image/edit")
    suspend fun editImage(
        @Header("x-app-key") appKey: String,
        @Part image: MultipartBody.Part,
        @Part("prompt") prompt: RequestBody
    ): GenerateImageResponse

    @POST("api/video/text-to-video")
    suspend fun textToVideo(
        @Header("x-app-key") appKey: String,
        @Body body: TextToVideoRequest
    ): TaskResponse

    @GET("api/video/status/{taskId}")
    suspend fun videoStatus(
        @Header("x-app-key") appKey: String,
        @Path("taskId") taskId: String
    ): VideoStatusResponse
}

data class GenerateImageRequest(val prompt: String)
data class GenerateImageResponse(val success: Boolean, val mimeType: String, val imageBase64: String)
data class TextToVideoRequest(val prompt: String, val duration: Int = 5, val aspectRatio: String = "16:9")
data class TaskResponse(val success: Boolean, val taskId: String)
data class VideoStatusResponse(val success: Boolean, val status: Map<String, Any>)
```

تحويل الصورة المستلمة (base64) إلى Bitmap لعرضها:
```kotlin
val bytes = Base64.decode(response.imageBase64, Base64.DEFAULT)
val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
imageView.setImageBitmap(bitmap)
```

لمتابعة الفيديو (polling كل 4 ثوانٍ):
```kotlin
suspend fun pollVideoUntilDone(taskId: String): String {
    while (true) {
        val res = api.videoStatus(APP_KEY, taskId)
        val status = res.status["task_status"] as? String
        if (status == "succeed") {
            return (res.status["task_result"] as Map<*, *>)
                .let { it["videos"] as List<*> }
                .let { (it[0] as Map<*, *>)["url"] as String }
        }
        if (status == "failed") throw Exception("فشل توليد الفيديو")
        delay(4000)
    }
}
```

## 6. النشر (Deployment) — مجانًا

أرخص وأسهل خيارات للنشر بدون تكلفة للبداية:
- **Render.com** (Free/Starter tier) — أسهل، دعم مباشر لمشاريع Node.js من GitHub
- **Railway.app** — حد مجاني شهري، نشر بضغطة زر
- **Fly.io** — حد مجاني سخي للتطبيقات الصغيرة

بعد النشر، استبدل `http://localhost:3000` في تطبيق الأندرويد برابط الخادم الحقيقي (يفضّل عبر HTTPS دائمًا).

## 7. ملاحظات مهمة

- **الحدود المجانية تتغير باستمرار** — تحقق من لوحة تحكم كل خدمة بانتظام.
- Kling AI يستخدم مصادقة JWT (Access Key + Secret Key) صالحة 30 دقيقة، الكود يولّدها تلقائيًا مع كل طلب.
- فيديوهات Kling تُحذف من خوادمهم بعد 30 يومًا — نزّلها وارفعها لتخزينك الخاص (مثل Firebase Storage أو S3) إذا أردت الاحتفاظ بها.
- أضف نظام حسابات مستخدمين + حد استخدام يومي لكل مستخدم لاحقًا لحماية ميزانيتك من الاستغلال.
