// middleware/apiKeyAuth.js
// يتحقق أن الطلب قادم من تطبيقك فقط (وليس من أي شخص وجد رابط الخادم)
// تطبيق الأندرويد يجب أن يرسل هيدر: x-app-key: <نفس قيمة APP_SECRET_KEY>

module.exports = function apiKeyAuth(req, res, next) {
  const clientKey = req.header("x-app-key");
  const serverKey = process.env.APP_SECRET_KEY;

  if (!serverKey) {
    // لو لم تُضبط القيمة، امنع كل شيء حماية لك من نسيان الإعداد
    return res.status(500).json({ error: "APP_SECRET_KEY غير مضبوط على الخادم" });
  }

  if (!clientKey || clientKey !== serverKey) {
    return res.status(401).json({ error: "غير مصرح: مفتاح التطبيق مفقود أو خاطئ" });
  }

  next();
};
