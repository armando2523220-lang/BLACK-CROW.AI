package com.aiphotostudio.app.ui.screens

import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.aiphotostudio.app.R
import com.aiphotostudio.app.editor.AdjustValues
import com.aiphotostudio.app.editor.FilterPreset
import com.aiphotostudio.app.editor.ImageEditorEngine
import com.aiphotostudio.app.ui.components.AppTopBar
import com.aiphotostudio.app.ui.components.GradientButton
import com.aiphotostudio.app.ui.components.screenPadding
import com.aiphotostudio.app.ui.theme.BrandSurfaceVariant
import com.aiphotostudio.app.util.ImageUtils

@Composable
fun EffectsScreen(navController: NavHostController) {
    val context = LocalContext.current

    var originalBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var preset by remember { mutableStateOf(FilterPreset.NONE) }

    var brightness by remember { mutableFloatStateOf(100f) }
    var contrast by remember { mutableFloatStateOf(100f) }
    var saturation by remember { mutableFloatStateOf(100f) }
    var warmth by remember { mutableFloatStateOf(100f) }

    val pickImageLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            originalBitmap = ImageUtils.uriToBitmap(context, it)
            preset = FilterPreset.NONE
            brightness = 100f; contrast = 100f; saturation = 100f; warmth = 100f
        }
    }

    // نحسب المعاينة الحيّة عند كل تغيير (bitmaps صغيرة نسبيًا فلا مشكلة أداء ملحوظة)
    val previewBitmap = remember(originalBitmap, preset, brightness, contrast, saturation, warmth) {
        val source = originalBitmap ?: return@remember null
        val afterPreset = ImageEditorEngine.applyFilterPreset(source, preset)
        ImageEditorEngine.applyAdjustments(
            afterPreset,
            AdjustValues(brightness.toInt(), contrast.toInt(), saturation.toInt(), warmth.toInt())
        )
    }

    Scaffold(topBar = { AppTopBar(stringResource(R.string.effects_title)) { navController.popBackStack() } }) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(screenPadding)
                .verticalScroll(rememberScrollState())
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(260.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(BrandSurfaceVariant)
                    .clickable { pickImageLauncher.launch("image/*") },
                contentAlignment = Alignment.Center
            ) {
                if (previewBitmap != null) {
                    Image(
                        bitmap = previewBitmap.asImageBitmap(),
                        contentDescription = "معاينة",
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Text(stringResource(R.string.pick_image))
                }
            }

            Spacer(Modifier.height(16.dp))

            // اختصارات الفلاتر الجاهزة (ضغطة واحدة)
            Text("فلاتر جاهزة", fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            val presets = listOf(
                FilterPreset.NONE to stringResource(R.string.filter_none),
                FilterPreset.BLACK_WHITE to stringResource(R.string.filter_bw),
                FilterPreset.SEPIA to stringResource(R.string.filter_sepia),
                FilterPreset.VINTAGE to stringResource(R.string.filter_vintage),
                FilterPreset.VIVID to stringResource(R.string.filter_vivid),
                FilterPreset.COOL to stringResource(R.string.filter_cool),
            )
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(presets) { (value, label) ->
                    AssistChip(
                        onClick = { preset = value },
                        label = { Text(label) }
                    )
                }
            }

            Spacer(Modifier.height(20.dp))

            AdjustSlider(stringResource(R.string.brightness), brightness) { brightness = it }
            AdjustSlider(stringResource(R.string.contrast), contrast) { contrast = it }
            AdjustSlider(stringResource(R.string.saturation), saturation) { saturation = it }
            AdjustSlider(stringResource(R.string.warmth), warmth) { warmth = it }

            Spacer(Modifier.height(12.dp))

            // اختصارات سريعة: تدوير وقص مربع
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                TextButton(onClick = {
                    originalBitmap?.let { originalBitmap = ImageEditorEngine.rotate(it, 90f) }
                }) { Text(stringResource(R.string.rotate)) }

                TextButton(onClick = {
                    originalBitmap?.let { originalBitmap = ImageEditorEngine.cropToSquare(it) }
                }) { Text(stringResource(R.string.crop_square)) }

                TextButton(onClick = {
                    preset = FilterPreset.NONE
                    brightness = 100f; contrast = 100f; saturation = 100f; warmth = 100f
                }) { Text(stringResource(R.string.reset)) }
            }

            Spacer(Modifier.height(16.dp))

            GradientButton(
                text = stringResource(R.string.save_image),
                enabled = previewBitmap != null
            ) {
                previewBitmap?.let { bitmap ->
                    val uri = ImageUtils.saveBitmapToGallery(context, bitmap, "ai_effect_${System.currentTimeMillis()}.jpg")
                    Toast.makeText(
                        context,
                        if (uri != null) "تم الحفظ في المعرض" else "فشل الحفظ",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun AdjustSlider(label: String, value: Float, onChange: (Float) -> Unit) {
    Column(modifier = Modifier.padding(vertical = 6.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label)
            Text("${value.toInt()}%")
        }
        Slider(value = value, onValueChange = onChange, valueRange = 0f..200f)
    }
}
