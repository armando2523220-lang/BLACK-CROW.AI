package com.aiphotostudio.app.ui.screens

import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.aiphotostudio.app.R
import com.aiphotostudio.app.network.AiRepository
import com.aiphotostudio.app.ui.components.AppTopBar
import com.aiphotostudio.app.ui.components.ErrorBanner
import com.aiphotostudio.app.ui.components.GradientButton
import com.aiphotostudio.app.ui.components.screenPadding
import com.aiphotostudio.app.ui.theme.BrandSurfaceVariant
import com.aiphotostudio.app.util.ImageUtils
import com.aiphotostudio.app.util.VideoUtils
import kotlinx.coroutines.launch

@Composable
fun ImageToVideoScreen(navController: NavHostController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val repository = remember { AiRepository(context) }

    var originalBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var prompt by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var statusText by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var videoUrl by remember { mutableStateOf<String?>(null) }

    val pickImageLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            originalBitmap = ImageUtils.uriToBitmap(context, it)
            videoUrl = null
        }
    }

    Scaffold(topBar = { AppTopBar(stringResource(R.string.image_to_video_title)) { navController.popBackStack() } }) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(screenPadding)
                .verticalScroll(rememberScrollState())
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(BrandSurfaceVariant)
                    .clickable { pickImageLauncher.launch("image/*") },
                contentAlignment = Alignment.Center
            ) {
                originalBitmap?.let { bitmap ->
                    Image(
                        bitmap = bitmap.asImageBitmap(),
                        contentDescription = "الصورة المختارة",
                        modifier = Modifier.fillMaxSize()
                    )
                } ?: Text(stringResource(R.string.pick_image))
            }

            Spacer(Modifier.height(16.dp))

            OutlinedTextField(
                value = prompt,
                onValueChange = { prompt = it },
                label = { Text(stringResource(R.string.motion_prompt_hint)) },
                modifier = Modifier.fillMaxWidth(),
                minLines = 2
            )

            Spacer(Modifier.height(16.dp))

            GradientButton(
                text = if (loading) stringResource(R.string.video_processing) else stringResource(R.string.create_video),
                loading = loading,
                enabled = originalBitmap != null
            ) {
                val bitmap = originalBitmap ?: return@GradientButton
                errorMessage = null
                videoUrl = null
                loading = true
                statusText = "جاري رفع الصورة…"
                scope.launch {
                    try {
                        val base64 = ImageUtils.bitmapToBase64(bitmap)
                        val taskId = repository.imageToVideoFromBase64(base64, prompt.trim(), 5)
                        if (taskId == null) {
                            errorMessage = context.getString(R.string.error_generic)
                            loading = false
                            return@launch
                        }
                        val result = repository.pollVideoUntilDone(taskId) { attempt ->
                            statusText = "جاري المعالجة… (محاولة $attempt)"
                        }
                        if (result.isDone && result.videoUrl != null) {
                            videoUrl = result.videoUrl
                        } else {
                            errorMessage = "تعذّر إنشاء الفيديو، حاول مرة أخرى"
                        }
                    } catch (e: Exception) {
                        errorMessage = e.message ?: context.getString(R.string.error_generic)
                    } finally {
                        loading = false
                    }
                }
            }

            if (loading) {
                Spacer(Modifier.height(12.dp))
                Row {
                    CircularProgressIndicator(modifier = Modifier.height(20.dp))
                    Spacer(Modifier.width(10.dp))
                    Text(statusText)
                }
            }

            Spacer(Modifier.height(12.dp))
            errorMessage?.let { ErrorBanner(it) }

            videoUrl?.let { url ->
                Spacer(Modifier.height(16.dp))
                Text(stringResource(R.string.video_ready))
                Spacer(Modifier.height(8.dp))
                VideoPlayer(url = url, modifier = Modifier
                    .fillMaxWidth()
                    .height(260.dp))

                Spacer(Modifier.height(12.dp))
                GradientButton(text = stringResource(R.string.save_video)) {
                    scope.launch {
                        try {
                            val uri = VideoUtils.downloadAndSaveVideo(context, url, "ai_video_${System.currentTimeMillis()}.mp4")
                            Toast.makeText(
                                context,
                                if (uri != null) "تم الحفظ في المعرض" else "فشل الحفظ",
                                Toast.LENGTH_SHORT
                            ).show()
                        } catch (e: Exception) {
                            Toast.makeText(context, e.message ?: "فشل الحفظ", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
        }
    }
}
