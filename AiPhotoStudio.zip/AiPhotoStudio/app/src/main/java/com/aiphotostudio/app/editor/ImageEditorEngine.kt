package com.aiphotostudio.app.editor

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint

/** فلاتر جاهزة (اختصارات سريعة) يمكن تطبيقها بضغطة واحدة */
enum class FilterPreset {
    NONE, BLACK_WHITE, SEPIA, VINTAGE, VIVID, COOL
}

/** قيم التعديل اليدوي، من 0..200 حيث 100 = القيمة الطبيعية بدون تغيير */
data class AdjustValues(
    val brightness: Int = 100,
    val contrast: Int = 100,
    val saturation: Int = 100,
    val warmth: Int = 100
)

object ImageEditorEngine {

    /** يطبّق تعديلات السطوع/التباين/التشبع/الدفء دفعة واحدة عبر ColorMatrix (أداء عالٍ) */
    fun applyAdjustments(source: Bitmap, values: AdjustValues): Bitmap {
        val result = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        val brightnessOffset = (values.brightness - 100) * 1.5f
        val contrastScale = values.contrast / 100f
        val saturationScale = values.saturation / 100f
        val warmthShift = (values.warmth - 100) * 0.4f

        val contrastTranslate = (1 - contrastScale) * 128f

        val cm = ColorMatrix()
        val satMatrix = ColorMatrix().apply { setSaturation(saturationScale) }
        val contrastBrightnessMatrix = ColorMatrix(
            floatArrayOf(
                contrastScale, 0f, 0f, 0f, contrastTranslate + brightnessOffset + warmthShift,
                0f, contrastScale, 0f, 0f, contrastTranslate + brightnessOffset,
                0f, 0f, contrastScale, 0f, contrastTranslate + brightnessOffset - warmthShift,
                0f, 0f, 0f, 1f, 0f
            )
        )

        cm.postConcat(satMatrix)
        cm.postConcat(contrastBrightnessMatrix)

        paint.colorFilter = ColorMatrixColorFilter(cm)
        canvas.drawBitmap(source, 0f, 0f, paint)
        return result
    }

    /** يطبّق أحد الفلاتر الجاهزة */
    fun applyFilterPreset(source: Bitmap, preset: FilterPreset): Bitmap {
        if (preset == FilterPreset.NONE) return source.copy(source.config ?: Bitmap.Config.ARGB_8888, true)

        val result = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        val matrix = when (preset) {
            FilterPreset.BLACK_WHITE -> ColorMatrix().apply { setSaturation(0f) }

            FilterPreset.SEPIA -> ColorMatrix(
                floatArrayOf(
                    0.393f, 0.769f, 0.189f, 0f, 0f,
                    0.349f, 0.686f, 0.168f, 0f, 0f,
                    0.272f, 0.534f, 0.131f, 0f, 0f,
                    0f, 0f, 0f, 1f, 0f
                )
            )

            FilterPreset.VINTAGE -> ColorMatrix(
                floatArrayOf(
                    0.9f, 0.1f, 0f, 0f, 10f,
                    0.05f, 0.85f, 0.05f, 0f, 5f,
                    0f, 0.15f, 0.75f, 0f, -10f,
                    0f, 0f, 0f, 1f, 0f
                )
            )

            FilterPreset.VIVID -> ColorMatrix().apply { setSaturation(1.6f) }

            FilterPreset.COOL -> ColorMatrix(
                floatArrayOf(
                    1f, 0f, 0f, 0f, -8f,
                    0f, 1f, 0f, 0f, 0f,
                    0f, 0f, 1f, 0f, 12f,
                    0f, 0f, 0f, 1f, 0f
                )
            )

            FilterPreset.NONE -> ColorMatrix()
        }

        paint.colorFilter = ColorMatrixColorFilter(matrix)
        canvas.drawBitmap(source, 0f, 0f, paint)
        return result
    }

    /** يدوّر الصورة بزاوية معينة (90 درجة تدريجيًا عادة) */
    fun rotate(source: Bitmap, degrees: Float): Bitmap {
        val matrix = Matrix().apply { postRotate(degrees) }
        return Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
    }

    /** يقص الصورة إلى مربع من المنتصف (اختصار سريع شائع للمشاركة على السوشيال ميديا) */
    fun cropToSquare(source: Bitmap): Bitmap {
        val size = minOf(source.width, source.height)
        val x = (source.width - size) / 2
        val y = (source.height - size) / 2
        return Bitmap.createBitmap(source, x, y, size, size)
    }
}
