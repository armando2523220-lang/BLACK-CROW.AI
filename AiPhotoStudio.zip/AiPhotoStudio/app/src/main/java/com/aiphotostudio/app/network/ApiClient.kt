package com.aiphotostudio.app.network

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

/**
 * ينشئ عميل Retrofit جديدًا في كل مرة لأن رابط الخادم قابل للتغيير من شاشة الإعدادات
 * (المستخدم قد يبدّل بين خادم محلي للتجربة وخادم منشور فعليًا).
 */
object ApiClient {

    fun create(baseUrl: String): AiApiService {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        }

        val okHttpClient = OkHttpClient.Builder()
            .addInterceptor(logging)
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(120, TimeUnit.SECONDS) // توليد الصور/الفيديو قد يستغرق وقتًا
            .writeTimeout(60, TimeUnit.SECONDS)
            .build()

        val safeBaseUrl = if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/"

        return Retrofit.Builder()
            .baseUrl(safeBaseUrl)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(AiApiService::class.java)
    }
}
