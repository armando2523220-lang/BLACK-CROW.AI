package com.aiphotostudio.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PhotoFilter
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SlowMotionVideo
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.aiphotostudio.app.R
import com.aiphotostudio.app.navigation.Screen
import com.aiphotostudio.app.ui.components.FeatureCard
import com.aiphotostudio.app.ui.theme.BrandOnSurfaceMuted

private data class HomeAction(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val route: String
)

@Composable
fun HomeScreen(navController: NavHostController) {
    val actions = listOf(
        HomeAction("توليد صورة", "من نص إلى صورة بالذكاء الاصطناعي", Icons.Filled.AutoAwesome, Screen.Generate.route),
        HomeAction("تعديل صورة", "عدّل صورتك بوصف نصي بسيط", Icons.Filled.AutoFixHigh, Screen.Edit.route),
        HomeAction("تأثيرات وفلاتر", "سطوع، تباين، فلاتر جاهزة، تدوير وقص", Icons.Filled.PhotoFilter, Screen.Effects.route),
        HomeAction("نص إلى فيديو", "أنشئ مقطع فيديو من وصف نصي", Icons.Filled.Movie, Screen.TextToVideo.route),
        HomeAction("صورة إلى فيديو", "حرّك صورتك الثابتة وحوّلها لفيديو", Icons.Filled.SlowMotionVideo, Screen.ImageToVideo.route),
        HomeAction("الإعدادات", "رابط الخادم ومفتاح الوصول", Icons.Filled.Settings, Screen.Settings.route),
    )

    Scaffold { padding ->
        Column(modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .padding(horizontal = 20.dp)
        ) {
            Column(modifier = Modifier.padding(top = 24.dp, bottom = 8.dp)) {
                Text(
                    stringResource(R.string.home_title),
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.ExtraBold
                )
                Text(
                    stringResource(R.string.home_subtitle),
                    style = MaterialTheme.typography.bodyLarge,
                    color = BrandOnSurfaceMuted,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(vertical = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(actions) { action ->
                    FeatureCard(
                        title = action.title,
                        subtitle = action.subtitle,
                        icon = action.icon,
                        modifier = Modifier.height(150.dp),
                        onClick = { navController.navigate(action.route) }
                    )
                }
            }
        }
    }
}
