package com.aiphotostudio.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColors = darkColorScheme(
    primary = BrandPurple,
    secondary = BrandPink,
    background = BrandDark,
    surface = BrandSurface,
    surfaceVariant = BrandSurfaceVariant,
    onBackground = BrandOnSurface,
    onSurface = BrandOnSurface,
    error = BrandError
)

@Composable
fun AiPhotoStudioTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    // التطبيق مصمم أساسًا بوضع داكن أنيق يناسب استوديو صور بالذكاء الاصطناعي
    MaterialTheme(
        colorScheme = DarkColors,
        typography = AppTypography,
        content = content
    )
}
