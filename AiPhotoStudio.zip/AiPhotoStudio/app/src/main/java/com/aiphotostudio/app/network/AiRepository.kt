package com.aiphotostudio.app.network

import android.content.Context
import com.aiphotostudio.app.data.PrefsManager
import com.aiphotostudio.app.network.models.GenerateImageRequest
import com.aiphotostudio.app.network.models.ImageResponse
import com.aiphotostudio.app.network.models.ImageToVideoRequest
import com.aiphotostudio.app.network.models.TextToVideoRequest
import com.aiphotostudio.app.network.models.VideoResult
import kotlinx.coroutines.delay
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File

class AiRepository(context: Context) {

    private val prefs = PrefsManager(context)

    private suspend fun apiKeyOrThrow(): String {
        val key = prefs.getAppKey()
        if (key.isBlank()) throw IllegalStateException("لم يتم ضبط مفتاح التطبيق من الإعدادات")
        return key
    }

    private suspend fun service() = ApiClient.create(prefs.getServerUrl())

    suspend fun generateImage(prompt: String): ImageResponse {
        return service().generateImage(apiKeyOrThrow(), GenerateImageRequest(prompt))
    }

    suspend fun editImage(imageFile: File, mimeType: String, prompt: String): ImageResponse {
        val requestFile = imageFile.asRequestBody(mimeType.toMediaTypeOrNull())
        val imagePart = MultipartBody.Part.createFormData("image", imageFile.name, requestFile)
        val promptBody = prompt.toRequestBody("text/plain".toMediaTypeOrNull())
        return service().editImage(apiKeyOrThrow(), imagePart, promptBody)
    }

    suspend fun textToVideo(prompt: String, duration: Int, aspectRatio: String): String? {
        val res = service().textToVideo(
            apiKeyOrThrow(),
            TextToVideoRequest(prompt, duration, aspectRatio)
        )
        return res.taskId
    }

    suspend fun imageToVideoFromUrl(imageUrl: String, prompt: String, duration: Int): String? {
        val res = service().imageToVideo(
            apiKeyOrThrow(),
            ImageToVideoRequest(imageUrl = imageUrl, prompt = prompt, duration = duration)
        )
        return res.taskId
    }

    suspend fun imageToVideoFromBase64(imageBase64: String, prompt: String, duration: Int): String? {
        val res = service().imageToVideo(
            apiKeyOrThrow(),
            ImageToVideoRequest(imageBase64 = imageBase64, prompt = prompt, duration = duration)
        )
        return res.taskId
    }

    /**
     * يستدعي حالة المهمة مرة واحدة ويحوّلها لشكل موحّد.
     * رد Kling الحقيقي متغيّر الحقول قليلًا حسب النسخة، لذا نبحث بمرونة عن status/url.
     */
    suspend fun checkVideoStatus(taskId: String): VideoResult {
        val res = service().videoStatus(apiKeyOrThrow(), taskId)
        val statusMap = res.status ?: return VideoResult(isDone = false, isFailed = false)

        val taskStatus = (statusMap["task_status"] ?: statusMap["status"])?.toString()?.lowercase()

        val isFailed = taskStatus == "failed" || taskStatus == "fail"
        val isDone = taskStatus == "succeed" || taskStatus == "success" || taskStatus == "completed"

        var videoUrl: String? = null
        if (isDone) {
            @Suppress("UNCHECKED_CAST")
            val result = statusMap["task_result"] as? Map<String, Any>
            val videos = result?.get("videos") as? List<Map<String, Any>>
            videoUrl = videos?.firstOrNull()?.get("url")?.toString()
                ?: statusMap["video"]?.let { (it as? Map<*, *>)?.get("url")?.toString() }
                ?: statusMap["video_url"]?.toString()
        }

        return VideoResult(isDone = isDone, isFailed = isFailed, videoUrl = videoUrl)
    }

    /**
     * يستطلع (poll) حالة الفيديو كل [intervalMs] حتى الانتهاء أو الفشل أو انتهاء [timeoutMs].
     */
    suspend fun pollVideoUntilDone(
        taskId: String,
        intervalMs: Long = 4000,
        timeoutMs: Long = 5 * 60 * 1000,
        onTick: (attempt: Int) -> Unit = {}
    ): VideoResult {
        val startTime = System.currentTimeMillis()
        var attempt = 0
        while (System.currentTimeMillis() - startTime < timeoutMs) {
            attempt++
            onTick(attempt)
            val result = checkVideoStatus(taskId)
            if (result.isDone || result.isFailed) return result
            delay(intervalMs)
        }
        return VideoResult(isDone = false, isFailed = true)
    }
}
