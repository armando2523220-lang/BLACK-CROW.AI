package com.aiphotostudio.app.util

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

object VideoUtils {

    /** يحمّل الفيديو من رابط مباشر ويحفظه في معرض الفيديوهات */
    suspend fun downloadAndSaveVideo(context: Context, videoUrl: String, displayName: String): Uri? =
        withContext(Dispatchers.IO) {
            val connection = URL(videoUrl).openConnection() as HttpURLConnection
            connection.connect()

            val resolver = context.contentResolver
            val targetUri: Uri? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/AiPhotoStudio")
                }
                resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            } else {
                @Suppress("DEPRECATION")
                val dir = File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                    "AiPhotoStudio"
                )
                if (!dir.exists()) dir.mkdirs()
                Uri.fromFile(File(dir, displayName))
            }

            targetUri?.let { uri ->
                val outStream = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    resolver.openOutputStream(uri)
                } else {
                    java.io.FileOutputStream(uri.path)
                }
                outStream?.use { out ->
                    connection.inputStream.use { input -> input.copyTo(out) }
                }
            }
            connection.disconnect()
            targetUri
        }
}
