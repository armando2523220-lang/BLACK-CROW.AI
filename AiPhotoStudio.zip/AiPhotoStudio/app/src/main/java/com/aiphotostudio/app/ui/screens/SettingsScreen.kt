package com.aiphotostudio.app.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.aiphotostudio.app.R
import com.aiphotostudio.app.data.PrefsManager
import com.aiphotostudio.app.ui.components.AppTopBar
import com.aiphotostudio.app.ui.components.GradientButton
import com.aiphotostudio.app.ui.components.screenPadding
import com.aiphotostudio.app.ui.theme.BrandOnSurfaceMuted
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(navController: NavHostController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { PrefsManager(context) }

    var serverUrl by remember { mutableStateOf("") }
    var appKey by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        serverUrl = prefs.getServerUrl()
        appKey = prefs.getAppKey()
    }

    Scaffold(topBar = { AppTopBar(stringResource(R.string.settings_title)) { navController.popBackStack() } }) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(screenPadding)
        ) {
            Text(
                "اربط التطبيق بخادمك الوسيط (Backend) الذي أنشأته سابقًا. راجع ملف ai-backend/README.md لمعرفة كيفية نشره.",
                color = BrandOnSurfaceMuted
            )

            Spacer(Modifier.height(20.dp))

            OutlinedTextField(
                value = serverUrl,
                onValueChange = { serverUrl = it },
                label = { Text(stringResource(R.string.server_url_label)) },
                placeholder = { Text("https://your-backend.example.com/") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Spacer(Modifier.height(16.dp))

            OutlinedTextField(
                value = appKey,
                onValueChange = { appKey = it },
                label = { Text(stringResource(R.string.app_key_label)) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                visualTransformation = PasswordVisualTransformation()
            )

            Spacer(Modifier.height(24.dp))

            GradientButton(text = stringResource(R.string.save_settings)) {
                scope.launch {
                    prefs.saveSettings(serverUrl, appKey)
                    Toast.makeText(context, context.getString(R.string.settings_saved), Toast.LENGTH_SHORT).show()
                }
            }

            Spacer(Modifier.height(16.dp))
            Text(
                "ملاحظة: عند التجربة على المحاكي (Emulator)، استخدم 10.0.2.2 للإشارة إلى localhost على جهازك. عند التجربة على هاتف حقيقي، استخدم رابط الخادم المنشور فعليًا عبر HTTPS.",
                color = BrandOnSurfaceMuted
            )
        }
    }
}
