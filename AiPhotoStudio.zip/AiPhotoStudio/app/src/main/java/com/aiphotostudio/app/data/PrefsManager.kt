package com.aiphotostudio.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "ai_photo_studio_settings")

/**
 * يخزّن رابط الخادم الوسيط (Backend) ومفتاح x-app-key محليًا على الجهاز.
 * لا تُخزَّن هنا أي مفاتيح Google/Kling مباشرة — هذه تبقى على الخادم فقط.
 */
class PrefsManager(private val context: Context) {

    companion object {
        private val KEY_SERVER_URL = stringPreferencesKey("server_url")
        private val KEY_APP_KEY = stringPreferencesKey("app_key")

        // عدّل هذا الرابط الافتراضي بعد نشر الخادم (راجع دليل ai-backend/README.md)
        const val DEFAULT_SERVER_URL = "http://10.0.2.2:3000/"
    }

    val serverUrlFlow = context.dataStore.data.map { prefs ->
        prefs[KEY_SERVER_URL]?.takeIf { it.isNotBlank() } ?: DEFAULT_SERVER_URL
    }

    val appKeyFlow = context.dataStore.data.map { prefs -> prefs[KEY_APP_KEY] ?: "" }

    suspend fun getServerUrl(): String = serverUrlFlow.first()
    suspend fun getAppKey(): String = appKeyFlow.first()

    suspend fun saveSettings(serverUrl: String, appKey: String) {
        context.dataStore.edit { prefs ->
            var normalized = serverUrl.trim()
            if (normalized.isNotEmpty() && !normalized.endsWith("/")) normalized += "/"
            prefs[KEY_SERVER_URL] = normalized.ifBlank { DEFAULT_SERVER_URL }
            prefs[KEY_APP_KEY] = appKey.trim()
        }
    }
}
