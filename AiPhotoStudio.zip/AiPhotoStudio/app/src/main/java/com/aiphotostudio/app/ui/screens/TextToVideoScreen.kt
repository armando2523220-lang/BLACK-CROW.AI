package com.aiphotostudio.app.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.NavHostController
import com.aiphotostudio.app.R
import com.aiphotostudio.app.network.AiRepository
import com.aiphotostudio.app.ui.components.AppTopBar
import com.aiphotostudio.app.ui.components.ErrorBanner
import com.aiphotostudio.app.ui.components.GradientButton
import com.aiphotostudio.app.ui.components.screenPadding
import com.aiphotostudio.app.util.VideoUtils
import kotlinx.coroutines.launch

@Composable
fun TextToVideoScreen(navController: NavHostController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val repository = remember { AiRepository(context) }

    var prompt by remember { mutableStateOf("") }
    var duration by remember { mutableStateOf(5) }
    var loading by remember { mutableStateOf(false) }
    var statusText by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var videoUrl by remember { mutableStateOf<String?>(null) }

    Scaffold(topBar = { AppTopBar(stringResource(R.string.text_to_video_title)) { navController.popBackStack() } }) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(screenPadding)
                .verticalScroll(rememberScrollState())
        ) {
            OutlinedTextField(
                value = prompt,
                onValueChange = { prompt = it },
                label = { Text(stringResource(R.string.video_prompt_hint)) },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3
            )

            Spacer(Modifier.height(12.dp))

            Text("مدة الفيديو")
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(5, 10).forEach { seconds ->
                    FilterChip(
                        selected = duration == seconds,
                        onClick = { duration = seconds },
                        label = { Text("$seconds ث") }
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            GradientButton(
                text = if (loading) stringResource(R.string.video_processing) else stringResource(R.string.create_video),
                loading = loading,
                enabled = prompt.isNotBlank()
            ) {
                errorMessage = null
                videoUrl = null
                loading = true
                statusText = "جاري إرسال الطلب…"
                scope.launch {
                    try {
                        val taskId = repository.textToVideo(prompt.trim(), duration, "16:9")
                        if (taskId == null) {
                            errorMessage = context.getString(R.string.error_generic)
                            loading = false
                            return@launch
                        }
                        val result = repository.pollVideoUntilDone(taskId) { attempt ->
                            statusText = "جاري المعالجة… (محاولة $attempt)"
                        }
                        if (result.isDone && result.videoUrl != null) {
                            videoUrl = result.videoUrl
                        } else {
                            errorMessage = "تعذّر إنشاء الفيديو، حاول مرة أخرى"
                        }
                    } catch (e: Exception) {
                        errorMessage = e.message ?: context.getString(R.string.error_generic)
                    } finally {
                        loading = false
                    }
                }
            }

            if (loading) {
                Spacer(Modifier.height(12.dp))
                Row {
                    CircularProgressIndicator(modifier = Modifier.height(20.dp))
                    Spacer(Modifier.width(10.dp))
                    Text(statusText)
                }
            }

            Spacer(Modifier.height(12.dp))
            errorMessage?.let { ErrorBanner(it) }

            videoUrl?.let { url ->
                Spacer(Modifier.height(16.dp))
                Text(stringResource(R.string.video_ready))
                Spacer(Modifier.height(8.dp))
                VideoPlayer(url = url, modifier = Modifier
                    .fillMaxWidth()
                    .height(260.dp))

                Spacer(Modifier.height(12.dp))
                GradientButton(text = stringResource(R.string.save_video)) {
                    scope.launch {
                        try {
                            val uri = VideoUtils.downloadAndSaveVideo(context, url, "ai_video_${System.currentTimeMillis()}.mp4")
                            Toast.makeText(
                                context,
                                if (uri != null) "تم الحفظ في المعرض" else "فشل الحفظ",
                                Toast.LENGTH_SHORT
                            ).show()
                        } catch (e: Exception) {
                            Toast.makeText(context, e.message ?: "فشل الحفظ", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun VideoPlayer(url: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val exoPlayer = remember(url) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(url))
            prepare()
            playWhenReady = true
        }
    }

    DisposableEffect(exoPlayer) {
        onDispose { exoPlayer.release() }
    }

    AndroidView(
        modifier = modifier,
        factory = {
            PlayerView(it).apply { player = exoPlayer }
        }
    )
}
