package com.aiphotostudio.app.ui.screens

import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.aiphotostudio.app.R
import com.aiphotostudio.app.network.AiRepository
import com.aiphotostudio.app.ui.components.AppTopBar
import com.aiphotostudio.app.ui.components.ErrorBanner
import com.aiphotostudio.app.ui.components.GradientButton
import com.aiphotostudio.app.ui.components.screenPadding
import com.aiphotostudio.app.ui.theme.BrandSurfaceVariant
import com.aiphotostudio.app.util.ImageUtils
import kotlinx.coroutines.launch

@Composable
fun EditImageScreen(navController: NavHostController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val repository = remember { AiRepository(context) }

    var originalBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var resultBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var prompt by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val pickImageLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            originalBitmap = ImageUtils.uriToBitmap(context, it)
            resultBitmap = null
        }
    }

    Scaffold(topBar = { AppTopBar(stringResource(R.string.edit_title)) { navController.popBackStack() } }) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(screenPadding)
                .verticalScroll(rememberScrollState())
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(BrandSurfaceVariant)
                    .clickable { pickImageLauncher.launch("image/*") },
                contentAlignment = Alignment.Center
            ) {
                val displayed = resultBitmap ?: originalBitmap
                if (displayed != null) {
                    Image(
                        bitmap = displayed.asImageBitmap(),
                        contentDescription = "الصورة المختارة",
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Text(stringResource(R.string.pick_image))
                }
            }

            Spacer(Modifier.height(16.dp))

            OutlinedTextField(
                value = prompt,
                onValueChange = { prompt = it },
                label = { Text(stringResource(R.string.edit_prompt_hint)) },
                modifier = Modifier.fillMaxWidth(),
                minLines = 2
            )

            Spacer(Modifier.height(16.dp))

            GradientButton(
                text = if (loading) stringResource(R.string.generating) else stringResource(R.string.apply_edit),
                loading = loading,
                enabled = originalBitmap != null && prompt.isNotBlank()
            ) {
                val source = originalBitmap ?: return@GradientButton
                errorMessage = null
                loading = true
                scope.launch {
                    try {
                        val file = ImageUtils.bitmapToCacheFile(context, source, "edit_source.jpg")
                        val response = repository.editImage(file, "image/jpeg", prompt.trim())
                        if (response.success && response.imageBase64 != null) {
                            resultBitmap = ImageUtils.base64ToBitmap(response.imageBase64)
                        } else {
                            errorMessage = response.error ?: context.getString(R.string.error_generic)
                        }
                    } catch (e: Exception) {
                        errorMessage = e.message ?: context.getString(R.string.error_generic)
                    } finally {
                        loading = false
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            errorMessage?.let { ErrorBanner(it) }

            resultBitmap?.let { bitmap ->
                Spacer(Modifier.height(12.dp))
                TextButton(onClick = {
                    val uri = ImageUtils.saveBitmapToGallery(context, bitmap, "ai_edited_${System.currentTimeMillis()}.jpg")
                    Toast.makeText(
                        context,
                        if (uri != null) "تم الحفظ في المعرض" else "فشل الحفظ",
                        Toast.LENGTH_SHORT
                    ).show()
                }) {
                    Text(stringResource(R.string.save_image))
                }
            }
        }
    }
}
