package com.aiphotostudio.app

import android.app.Application

class AiPhotoStudioApp : Application()
