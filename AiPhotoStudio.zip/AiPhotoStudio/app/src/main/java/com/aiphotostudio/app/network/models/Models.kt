package com.aiphotostudio.app.network.models

// ===== الصور =====
data class GenerateImageRequest(val prompt: String)

data class ImageResponse(
    val success: Boolean = false,
    val mimeType: String? = null,
    val imageBase64: String? = null,
    val error: String? = null
)

// ===== الفيديو =====
data class TextToVideoRequest(
    val prompt: String,
    val duration: Int = 5,
    val aspectRatio: String = "16:9"
)

data class ImageToVideoRequest(
    val imageUrl: String? = null,
    val imageBase64: String? = null,
    val prompt: String? = null,
    val duration: Int = 5
)

data class TaskResponse(
    val success: Boolean = false,
    val taskId: String? = null,
    val error: String? = null
)

data class VideoStatusResponse(
    val success: Boolean = false,
    val status: Map<String, Any>? = null,
    val error: String? = null
)

/** نتيجة موحّدة بعد استخراج رابط الفيديو من رد Kling المتغيّر الشكل */
data class VideoResult(
    val isDone: Boolean,
    val isFailed: Boolean,
    val videoUrl: String? = null
)
