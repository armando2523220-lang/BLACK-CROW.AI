package com.aiphotostudio.app.util

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

object ImageUtils {

    /** يحوّل Uri (من منتقي الصور) إلى Bitmap */
    fun uriToBitmap(context: Context, uri: Uri): Bitmap {
        val input = context.contentResolver.openInputStream(uri)
        return BitmapFactory.decodeStream(input).also { input?.close() }
    }

    /** يحوّل Bitmap إلى نص Base64 (JPEG بجودة 90) */
    fun bitmapToBase64(bitmap: Bitmap, quality: Int = 90): String {
        val out = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, quality, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    /** يحوّل نص Base64 القادم من الخادم إلى Bitmap */
    fun base64ToBitmap(base64: String): Bitmap {
        val bytes = Base64.decode(base64, Base64.NO_WRAP)
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    }

    /** يحفظ Bitmap في ملف مؤقت داخل cache، مفيد لرفعه كـ multipart */
    fun bitmapToCacheFile(context: Context, bitmap: Bitmap, name: String = "upload.jpg"): File {
        val file = File(context.cacheDir, name)
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
        }
        return file
    }

    /** يحفظ Bitmap في معرض الصور العام عبر MediaStore (يعمل من Android 10 فما فوق وأقل) */
    fun saveBitmapToGallery(context: Context, bitmap: Bitmap, displayName: String): Uri? {
        val resolver = context.contentResolver

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, displayName)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/AiPhotoStudio")
            }
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            uri?.let {
                resolver.openOutputStream(it)?.use { out ->
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out)
                }
            }
            uri
        } else {
            @Suppress("DEPRECATION")
            val dir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                "AiPhotoStudio"
            )
            if (!dir.exists()) dir.mkdirs()
            val file = File(dir, displayName)
            FileOutputStream(file).use { out -> bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out) }
            Uri.fromFile(file)
        }
    }
}
