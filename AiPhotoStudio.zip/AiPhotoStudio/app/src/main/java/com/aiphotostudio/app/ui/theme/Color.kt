package com.aiphotostudio.app.ui.theme

import androidx.compose.ui.graphics.Color

// هوية BLACK CROW AI: أسود عميق + ذهبي معدني كلون مميّز
val BrandPurple = Color(0xFFD4AF37)      // ذهبي (اللون المميز الأساسي)
val BrandPink = Color(0xFF9A9AA5)        // فضي رمادي (لون ثانوي للتدرجات)
val BrandDark = Color(0xFF08080A)        // أسود عميق تقريبًا خالص
val BrandSurface = Color(0xFF17161C)
val BrandSurfaceVariant = Color(0xFF232129)
val BrandOnSurface = Color(0xFFF5F3EE)
val BrandOnSurfaceMuted = Color(0xFFAFA9A0)
val BrandError = Color(0xFFFF6B6B)
val BrandSuccess = Color(0xFF4ADE80)
