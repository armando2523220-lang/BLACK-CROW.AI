package com.aiphotostudio.app.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.aiphotostudio.app.ui.screens.EditImageScreen
import com.aiphotostudio.app.ui.screens.EffectsScreen
import com.aiphotostudio.app.ui.screens.GenerateImageScreen
import com.aiphotostudio.app.ui.screens.HomeScreen
import com.aiphotostudio.app.ui.screens.ImageToVideoScreen
import com.aiphotostudio.app.ui.screens.SettingsScreen
import com.aiphotostudio.app.ui.screens.TextToVideoScreen

sealed class Screen(val route: String) {
    data object Home : Screen("home")
    data object Generate : Screen("generate")
    data object Edit : Screen("edit")
    data object Effects : Screen("effects")
    data object TextToVideo : Screen("text_to_video")
    data object ImageToVideo : Screen("image_to_video")
    data object Settings : Screen("settings")
}

@Composable
fun AppNavHost(navController: NavHostController = rememberNavController()) {
    NavHost(navController = navController, startDestination = Screen.Home.route) {
        composable(Screen.Home.route) { HomeScreen(navController) }
        composable(Screen.Generate.route) { GenerateImageScreen(navController) }
        composable(Screen.Edit.route) { EditImageScreen(navController) }
        composable(Screen.Effects.route) { EffectsScreen(navController) }
        composable(Screen.TextToVideo.route) { TextToVideoScreen(navController) }
        composable(Screen.ImageToVideo.route) { ImageToVideoScreen(navController) }
        composable(Screen.Settings.route) { SettingsScreen(navController) }
    }
}
