package com.aiphotostudio.app.network

import com.aiphotostudio.app.network.models.GenerateImageRequest
import com.aiphotostudio.app.network.models.ImageResponse
import com.aiphotostudio.app.network.models.ImageToVideoRequest
import com.aiphotostudio.app.network.models.TaskResponse
import com.aiphotostudio.app.network.models.TextToVideoRequest
import com.aiphotostudio.app.network.models.VideoStatusResponse
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import retrofit2.http.Path

interface AiApiService {

    @POST("api/image/generate")
    suspend fun generateImage(
        @Header("x-app-key") appKey: String,
        @Body body: GenerateImageRequest
    ): ImageResponse

    @Multipart
    @POST("api/image/edit")
    suspend fun editImage(
        @Header("x-app-key") appKey: String,
        @Part image: MultipartBody.Part,
        @Part("prompt") prompt: RequestBody
    ): ImageResponse

    @POST("api/video/text-to-video")
    suspend fun textToVideo(
        @Header("x-app-key") appKey: String,
        @Body body: TextToVideoRequest
    ): TaskResponse

    @POST("api/video/image-to-video")
    suspend fun imageToVideo(
        @Header("x-app-key") appKey: String,
        @Body body: ImageToVideoRequest
    ): TaskResponse

    @GET("api/video/status/{taskId}")
    suspend fun videoStatus(
        @Header("x-app-key") appKey: String,
        @Path("taskId") taskId: String
    ): VideoStatusResponse
}
