package com.aiphotostudio.app.ui.screens

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.navigation.NavHostController
import com.aiphotostudio.app.R
import com.aiphotostudio.app.network.AiRepository
import com.aiphotostudio.app.ui.components.AppTopBar
import com.aiphotostudio.app.ui.components.ErrorBanner
import com.aiphotostudio.app.ui.components.GradientButton
import com.aiphotostudio.app.ui.components.screenPadding
import com.aiphotostudio.app.util.ImageUtils
import kotlinx.coroutines.launch

@Composable
fun GenerateImageScreen(navController: NavHostController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val repository = remember { AiRepository(context) }

    var prompt by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var resultBitmap by remember { mutableStateOf<android.graphics.Bitmap?>(null) }

    Scaffold(topBar = { AppTopBar(stringResource(R.string.generate_title)) { navController.popBackStack() } }) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(screenPadding)
                .verticalScroll(rememberScrollState())
        ) {
            OutlinedTextField(
                value = prompt,
                onValueChange = { prompt = it },
                label = { Text(stringResource(R.string.prompt_hint)) },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done)
            )

            Spacer(Modifier.height(16.dp))

            GradientButton(
                text = if (loading) stringResource(R.string.generating) else stringResource(R.string.generate_button),
                loading = loading,
                enabled = prompt.isNotBlank()
            ) {
                errorMessage = null
                loading = true
                scope.launch {
                    try {
                        val response = repository.generateImage(prompt.trim())
                        if (response.success && response.imageBase64 != null) {
                            resultBitmap = ImageUtils.base64ToBitmap(response.imageBase64)
                        } else {
                            errorMessage = response.error ?: context.getString(R.string.error_generic)
                        }
                    } catch (e: Exception) {
                        errorMessage = e.message ?: context.getString(R.string.error_generic)
                    } finally {
                        loading = false
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
            errorMessage?.let { ErrorBanner(it) }

            resultBitmap?.let { bitmap ->
                Spacer(Modifier.height(20.dp))
                Image(
                    bitmap = bitmap.asImageBitmap(),
                    contentDescription = "الصورة المولّدة",
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(360.dp)
                )
                Spacer(Modifier.height(12.dp))
                Row {
                    TextButton(onClick = {
                        val uri = ImageUtils.saveBitmapToGallery(context, bitmap, "ai_generated_${System.currentTimeMillis()}.jpg")
                        Toast.makeText(
                            context,
                            if (uri != null) "تم الحفظ في المعرض" else "فشل الحفظ",
                            Toast.LENGTH_SHORT
                        ).show()
                    }) {
                        Text(stringResource(R.string.save_image))
                    }

                    Spacer(Modifier.width(8.dp))

                    TextButton(onClick = {
                        val file = ImageUtils.bitmapToCacheFile(context, bitmap, "share_${System.currentTimeMillis()}.jpg")
                        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                        val shareIntent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                            type = "image/jpeg"
                            putExtra(android.content.Intent.EXTRA_STREAM, uri)
                            addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        context.startActivity(android.content.Intent.createChooser(shareIntent, "مشاركة الصورة"))
                    }) {
                        Text("مشاركة")
                    }
                }
            }
        }
    }
}
