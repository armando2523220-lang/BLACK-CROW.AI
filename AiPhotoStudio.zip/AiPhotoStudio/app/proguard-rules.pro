# احتفظ بأسماء نماذج الشبكة (Retrofit/Gson) حتى لا يتعطل التحليل بعد التصغير
-keep class com.aiphotostudio.app.network.models.** { *; }
-keepattributes Signature
-keepattributes *Annotation*
-dontwarn okhttp3.**
-dontwarn retrofit2.**
